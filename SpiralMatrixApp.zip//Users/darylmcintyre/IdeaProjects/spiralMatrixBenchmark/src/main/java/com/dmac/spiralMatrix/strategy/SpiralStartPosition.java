package com.dmac.spiralMatrix.strategy;

public enum SpiralStartPosition {
    TOP_LEFT,
    TOP_RIGHT,
    BOTTOM_RIGHT,
    BOTTOM_LEFT
}