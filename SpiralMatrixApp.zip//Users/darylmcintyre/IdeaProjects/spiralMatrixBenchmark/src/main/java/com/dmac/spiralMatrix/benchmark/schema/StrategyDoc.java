package com.dmac.spiralMatrix.benchmark.schema;

public record StrategyDoc(String name, String description, String timeComplexity, String spaceComplexity, String reference) {}
