package com.dmac.spiralMatrix.strategy;

public enum SpiralDirection {
    CLOCKWISE,
    COUNTERCLOCKWISE
}
